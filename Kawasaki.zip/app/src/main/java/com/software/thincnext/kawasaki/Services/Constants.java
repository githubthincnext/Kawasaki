package com.software.thincnext.kawasaki.Services;

public class Constants {
    public static final String IS_LOGGED_IN = "is_logged_in";
    public static final String PREFERENCE_NAME = "shared_preference";
    public static final String BASE_URL= "http://thincnextproject.somee.com/";

}
